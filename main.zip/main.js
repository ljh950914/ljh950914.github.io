$(".VistA").hover(function(){
    $(".toggle").slideToggle();
  });